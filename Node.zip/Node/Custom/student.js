const calci=require('./calci')
const a=900
const b=3983
console.log(calci.add(a,b))
console.log(calci.diff(a,b))